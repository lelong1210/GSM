package config

import (
	"embed"
)

//go:embed deviceclass mapping
var FileSystem embed.FS
