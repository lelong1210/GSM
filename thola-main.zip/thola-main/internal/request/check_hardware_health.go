package request

// CheckHardwareHealthRequest
//
// CheckHardwareHealthRequest is the request struct for the check hardware health request.
//
// swagger:model
type CheckHardwareHealthRequest struct {
	CheckDeviceRequest
}
